#ifndef _ARDUINO_SECRETS_H_
#define _ARDUINO_SECRETS_H_

#define SECRET_SSID "IER"
#define SECRET_PASS "acadier2014"

#define SECRET_URL "http://iot.ier.unam.mx:8080/api/v1/nCsfwwiNH8JpXLmI2yuY/telemetry"
#define SECRET_WWW_USERNAME "admin"
#define SECRET_WWW_PASSWORD "password"

#endif
