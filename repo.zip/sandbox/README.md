# The sandbox

La caja de arena no es la caja para el gato, sino el lugar de juegos
para los niños.

Pongan aquí lo que quieran compartir, eventualmente se eliminará del
repositorio cuando esté terminado.

