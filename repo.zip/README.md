# co2
Repositorio para c'odigo y datos de los sensores de CO2 desarrollados en el IER
